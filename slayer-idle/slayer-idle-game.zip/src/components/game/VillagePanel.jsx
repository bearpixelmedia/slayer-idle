import React from "react";
import { VILLAGE_BUILDINGS, getBuildingUpgradeCost, canUnlockBuilding, canAffordUpgrade } from "@/lib/village";
import { formatNumber } from "@/lib/formatNumber";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, ChevronUp, Lock } from "lucide-react";
import { HUD_THEME } from "@/lib/hudTheme";

// Renders a cropped tile from a station sprite sheet
function StationIcon({ station, size = 36 }) {
  const scale = size / Math.min(station.tileW, station.tileH);
  const displayW = Math.round(station.tileW * scale);
  const displayH = Math.round(station.tileH * scale);
  const sheetW = Math.round(station.w * scale);
  const sheetH = Math.round(station.h * scale);
  const offsetX = Math.round(station.col * station.tileW * scale);
  const offsetY = Math.round(station.row * station.tileH * scale);
  return (
    <div style={{
      width: displayW,
      height: displayH,
      backgroundImage: `url(${station.url})`,
      backgroundSize: `${sheetW}px ${sheetH}px`,
      backgroundPosition: `-${offsetX}px -${offsetY}px`,
      backgroundRepeat: "no-repeat",
      imageRendering: "pixelated",
      flexShrink: 0,
    }} />
  );
}

function BuildingCard({ building, level, state, onUpgrade, maxLevel }) {
  const cost = getBuildingUpgradeCost(building, level);
  const unlocked = canUnlockBuilding(building, state);
  const canAfford = cost && canAffordUpgrade(cost, state);
  const isMaxed = level >= maxLevel;

  return (
    <motion.button
      onClick={() => canAfford && onUpgrade(building.id)}
      className={`w-full flex items-start gap-2 p-2 rounded-lg border transition-all ${
        !unlocked
          ? "bg-muted/20 border-border/30 opacity-50 cursor-not-allowed"
          : isMaxed
            ? "bg-green-900/20 border-green-500/30 cursor-default"
            : canAfford
              ? "bg-secondary/60 border-primary/30 hover:border-primary/60 hover:bg-secondary/80 cursor-pointer"
              : "bg-card/40 border-border/30 opacity-50 cursor-not-allowed"
      }`}
      whileTap={canAfford && !isMaxed ? { scale: 0.97 } : {}}
    >
      <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center overflow-hidden" style={{ imageRendering: "pixelated" }}>
        {!unlocked
          ? <Lock className="w-5 h-5 text-muted-foreground" />
          : building.spriteStation
          ? <StationIcon station={building.spriteStation} size={36} />
          : <span className="text-2xl">{building.icon}</span>
        }
      </div>
      <div className="flex-1 text-left min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-foreground truncate">{building.name}</span>
          {isMaxed && <span className="font-pixel text-[7px] text-green-400">MAX</span>}
        </div>
        <p className="text-[10px] text-muted-foreground mb-1">{building.description}</p>
        <div className="flex items-center justify-between mt-1">
          <span className="font-pixel text-[8px] text-muted-foreground">Lv.{level}</span>
          {cost && cost.coins !== undefined && !isMaxed && (
            <span className="font-pixel text-[8px]">
              <span className={canAfford ? "text-primary" : "text-muted-foreground/50"}>
                🪙 {formatNumber(cost.coins)} 👻 {cost.souls || 0}
              </span>
            </span>
          )}
        </div>
      </div>
    </motion.button>
  );
}

export default function VillagePanel({ state, onUpgradeBuilding }) {
  const [open, setOpen] = React.useState(false);

  const villageBuildings = state?.villageBuildings || {};
  const upgradedCount = (Array.isArray(VILLAGE_BUILDINGS) ? VILLAGE_BUILDINGS : []).filter((b) => (villageBuildings[b?.id] || 0) > 0).length;

  return (
    <div className={`rounded-lg ${HUD_THEME.panel.border} overflow-hidden`}>
      {/* Header toggle */}
      <button
        className={`w-full flex items-center justify-between px-3 py-2 ${HUD_THEME.panel.bg} hover:bg-card/80 transition-colors`}
        onClick={() => setOpen((o) => !o)}
      >
        <div className="flex items-center gap-2">
          <span className="text-lg">🏘️</span>
          <span className={`${HUD_THEME.text.label} text-primary`}>VILLAGE</span>
          <span className={`${HUD_THEME.text.small} text-muted-foreground`}>
            {upgradedCount}/{VILLAGE_BUILDINGS.length}
          </span>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-3 py-2 space-y-1.5">
              {(Array.isArray(VILLAGE_BUILDINGS) ? VILLAGE_BUILDINGS : []).map((building) => (
                <BuildingCard
                  key={building?.id}
                  building={building}
                  level={villageBuildings[building?.id] || 0}
                  state={state}
                  onUpgrade={onUpgradeBuilding}
                  maxLevel={building?.maxLevel}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}